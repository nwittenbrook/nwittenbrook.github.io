This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

Created by Natalie Wittenbrook in July 2018.


# Goal

Create a web app that connects to a third party MTG API to display creature cards in a dynamic format/infinite scroll




